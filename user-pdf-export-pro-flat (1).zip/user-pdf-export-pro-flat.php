<?php
/**
 * Plugin Name: User PDF Export Pro
 * Description: Export all WordPress users and their details as a neatly arranged PDF table from the WordPress admin.
 * Version: 1.0.1
 * Author: Codex
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * License: GPLv2 or later
 * Text Domain: user-pdf-export-pro
 */

if (!defined('ABSPATH')) {
    exit;
}

define('UPEP_VERSION', '1.0.1');

function upep_activate() {
    update_option('upep_version', UPEP_VERSION);
}
register_activation_hook(__FILE__, 'upep_activate');

function upep_admin_menu() {
    add_users_page(
        'User PDF Export',
        'User PDF Export',
        'list_users',
        'upep-user-pdf-export',
        'upep_render_admin_page'
    );
}
add_action('admin_menu', 'upep_admin_menu');

function upep_columns() {
    return array(
        'ID' => 'ID',
        'user_login' => 'Username',
        'display_name' => 'Display Name',
        'user_email' => 'Email',
        'phone' => 'Phone',
        'country' => 'Country',
        'gsp_account' => 'GSP Account',
        'wallet_balance' => 'Wallet Balance',
        'savings_balance' => 'Savings Balance',
        'nickname' => 'Nickname',
        'first_name' => 'First Name',
        'last_name' => 'Last Name',
        'roles' => 'Roles',
        'user_registered' => 'Registered Date',
        'user_url' => 'Website',
        'description' => 'Bio',
        'locale' => 'Locale',
        'user_status' => 'Status',
        'extra_meta' => 'Other User Meta',
    );
}

function upep_default_columns() {
    return array('ID', 'user_login', 'display_name', 'user_email', 'phone', 'country', 'gsp_account', 'wallet_balance', 'savings_balance');
}

function upep_bulk_export_columns() {
    return array('ID', 'user_login', 'user_email', 'display_name', 'phone', 'country', 'gsp_account', 'wallet_balance', 'savings_balance');
}

function upep_selected_columns() {
    $available = upep_columns();
    $requested = isset($_REQUEST['upep_columns']) ? (array) wp_unslash($_REQUEST['upep_columns']) : upep_default_columns();
    $selected = array();

    foreach ($requested as $column) {
        $column = sanitize_text_field($column);
        if (isset($available[$column])) {
            $selected[] = $column;
        }
    }

    $selected = array_values(array_unique($selected));
    return empty($selected) ? upep_default_columns() : $selected;
}

function upep_value(WP_User $user, $column) {
    switch ($column) {
        case 'ID':
            return (string) $user->ID;
        case 'nickname':
        case 'first_name':
        case 'last_name':
        case 'description':
        case 'locale':
            return (string) get_user_meta($user->ID, $column, true);
        case 'phone':
            return upep_profile_value($user, 'phone');
        case 'country':
            return upep_profile_value($user, 'country');
        case 'gsp_account':
            return upep_profile_value($user, 'gsp_account');
        case 'wallet_balance':
            return upep_profile_value($user, 'wallet_balance');
        case 'savings_balance':
            return upep_profile_value($user, 'savings_balance');
        case 'roles':
            return implode(', ', array_map('ucwords', str_replace('_', ' ', (array) $user->roles)));
        case 'user_registered':
            return mysql2date('Y-m-d H:i', $user->user_registered);
        case 'extra_meta':
            return upep_extra_meta($user->ID);
        default:
            return isset($user->{$column}) ? (string) $user->{$column} : '';
    }
}

function upep_profile_value(WP_User $user, $field) {
    $value = upep_user_meta_value($user->ID, upep_meta_keys_for_field($field));

    if ($value === '') {
        $value = upep_meta_keyword_value($user->ID, upep_keywords_for_field($field));
    }

    if ($value === '') {
        $value = upep_custom_table_value($user, $field);
    }

    if ($value === '' && $field === 'phone') {
        $value = upep_registrationmagic_phone($user);
    }

    if ($value === '' && $field === 'phone') {
        $value = upep_phone_pattern_from_user_meta($user->ID);
    }

    return $value === '' ? '-' : $value;
}

function upep_meta_keys_for_field($field) {
    $map = array(
        'phone' => array(
            'phone',
            'phone_number',
            'mobile',
            'mobile_number',
            'mobile_no',
            'telephone',
            'tel',
            'whatsapp',
            'whatsapp_number',
            'user_phone',
            'user_mobile',
            'billing_phone',
            'shipping_phone',
            'account_phone',
            'contact_phone',
            'contact_number',
            'rm_phone',
            'rm_mobile',
            'registration_phone',
            'registration_mobile',
            'registrationmagic_phone',
            'registrationmagic_mobile',
            'user_registration_phone',
            'user_registration_mobile',
            'ur_phone',
            'ur_mobile',
            'um_phone',
            'um_mobile',
            'um_phone_number',
            'um_mobile_number',
            'digits_phone',
            'digits_phone_no',
            'digits_mobile',
            'digits_mobile_no',
            'digits_full_number',
            'mepr-address-phone',
            'gsp_phone',
            'gsp_user_phone',
            'gsp_mobile',
            'gsp_user_mobile',
            'gsp2_phone',
            'gsp2_mobile',
            'globalswiftpay_phone',
            'globalswiftpay_user_phone',
            'globalswiftpay_mobile',
            'globalswiftpay_user_mobile',
        ),
        'country' => array(
            'country',
            'user_country',
            'billing_country',
            'account_country',
            'gsp_country',
            'gsp_user_country',
            'globalswiftpay_country',
            'globalswiftpay_user_country',
        ),
        'gsp_account' => array(
            'gsp_account',
            'gsp_account_id',
            'gsp_account_number',
            'gsp2_account',
            'gsp2_account_number',
            'account',
            'account_id',
            'account_number',
            'globalswiftpay_account',
            'globalswiftpay_account_number',
        ),
        'wallet_balance' => array(
            'wallet_balance',
            'user_wallet_balance',
            'balance',
            'account_balance',
            'gsp_balance',
            'gsp_wallet_balance',
            'gsp2_wallet_balance',
            'globalswiftpay_balance',
            'globalswiftpay_wallet_balance',
        ),
        'savings_balance' => array(
            'savings_balance',
            'saving_balance',
            'user_savings_balance',
            'user_saving_balance',
            'gsp_savings_balance',
            'gsp_saving_balance',
            'gsp2_savings_balance',
            'globalswiftpay_savings_balance',
            'globalswiftpay_saving_balance',
        ),
    );

    return isset($map[$field]) ? $map[$field] : array();
}

function upep_keywords_for_field($field) {
    $map = array(
        'phone' => array(array('phone'), array('mobile'), array('tel'), array('whatsapp'), array('contact', 'number')),
        'country' => array(array('country'), array('nation')),
        'gsp_account' => array(array('gsp', 'account'), array('gsp2', 'account'), array('account', 'number')),
        'wallet_balance' => array(array('wallet', 'balance'), array('main', 'balance'), array('available', 'balance')),
        'savings_balance' => array(array('saving'), array('savings')),
    );

    return isset($map[$field]) ? $map[$field] : array();
}

function upep_user_meta_value($user_id, array $keys) {
    foreach ($keys as $key) {
        $value = get_user_meta($user_id, $key, true);
        $value = upep_clean_value($value);
        if ($value !== '') {
            return $value;
        }
    }

    return '';
}

function upep_meta_keyword_value($user_id, array $keywords) {
    if (empty($keywords)) {
        return '';
    }

    $meta = get_user_meta($user_id);
    foreach ($meta as $key => $values) {
        $key_lc = strtolower((string) $key);
        $matched = upep_keyword_groups_match($key_lc, $keywords);

        if (!$matched || strpos($key_lc, 'session') !== false || strpos($key_lc, 'token') !== false || strpos($key_lc, 'capabilities') !== false) {
            continue;
        }

        $value = isset($values[0]) ? maybe_unserialize($values[0]) : '';
        $value = upep_clean_value($value);
        if ($value !== '') {
            return $value;
        }
    }

    return '';
}

function upep_keyword_groups_match($text, array $groups) {
    foreach ($groups as $group) {
        $group = is_array($group) ? $group : array($group);
        $matched = true;

        foreach ($group as $keyword) {
            if (strpos($text, strtolower((string) $keyword)) === false) {
                $matched = false;
                break;
            }
        }

        if ($matched) {
            return true;
        }
    }

    return false;
}

function upep_custom_table_value(WP_User $user, $field) {
    global $wpdb;

    $cache_key = 'upep_custom_profile_' . $user->ID;
    $cached = wp_cache_get($cache_key, 'user-pdf-export-pro');
    if (is_array($cached)) {
        return isset($cached[$field]) ? $cached[$field] : '';
    }

    $profile = array(
        'phone' => '',
        'country' => '',
        'gsp_account' => '',
        'wallet_balance' => '',
        'savings_balance' => '',
    );

    $tables = upep_candidate_tables();
    foreach ($tables as $table) {
        $columns = upep_table_columns($table);
        if (empty($columns)) {
            continue;
        }

        $identity = upep_table_identity_where($columns, $user);
        if (empty($identity)) {
            continue;
        }

        $row = $wpdb->get_row("SELECT * FROM `$table` WHERE " . $identity . ' LIMIT 1', ARRAY_A);
        if (empty($row)) {
            continue;
        }

        foreach ($profile as $profile_field => $current) {
            if ($current !== '') {
                continue;
            }

            $profile[$profile_field] = upep_row_value_for_field($row, $profile_field);
        }

        if (!in_array('', $profile, true)) {
            break;
        }
    }

    wp_cache_set($cache_key, $profile, 'user-pdf-export-pro', 120);

    return isset($profile[$field]) ? $profile[$field] : '';
}

function upep_candidate_tables() {
    global $wpdb;
    $cache_key = 'upep_candidate_tables';
    $cached = wp_cache_get($cache_key, 'user-pdf-export-pro');
    if (is_array($cached)) {
        return $cached;
    }

    $like = $wpdb->esc_like($wpdb->prefix) . '%';
    $tables = $wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s', $like));
    $matches = array();

    foreach ((array) $tables as $table) {
        $name = strtolower((string) $table);
        if (
            strpos($name, 'globalswift') !== false ||
            strpos($name, 'swiftpay') !== false ||
            strpos($name, 'gsp') !== false ||
            strpos($name, 'wallet') !== false ||
            strpos($name, 'balance') !== false ||
            strpos($name, 'profile') !== false ||
            strpos($name, 'member') !== false ||
            strpos($name, 'customer') !== false ||
            strpos($name, 'registration') !== false ||
            strpos($name, 'register') !== false ||
            strpos($name, '_rm_') !== false ||
            strpos($name, 'phone') !== false ||
            strpos($name, 'mobile') !== false
        ) {
            $matches[] = $table;
            continue;
        }

        $columns = upep_table_columns($table);
        if (upep_table_has_identity_columns($columns) && upep_table_has_profile_columns($columns)) {
            $matches[] = $table;
        }
    }

    wp_cache_set($cache_key, $matches, 'user-pdf-export-pro', 120);
    return $matches;
}

function upep_table_has_identity_columns(array $columns) {
    $identity_columns = array('user_id', 'wp_user_id', 'customer_id', 'member_id', 'uid', 'email', 'user_email', 'username', 'user_login', 'login');
    $map = array_flip($columns);

    foreach ($identity_columns as $column) {
        if (isset($map[$column])) {
            return true;
        }
    }

    return false;
}

function upep_table_has_profile_columns(array $columns) {
    foreach ($columns as $column) {
        $column = strtolower((string) $column);
        if (
            strpos($column, 'phone') !== false ||
            strpos($column, 'mobile') !== false ||
            strpos($column, 'tel') !== false ||
            strpos($column, 'country') !== false ||
            strpos($column, 'wallet') !== false ||
            strpos($column, 'balance') !== false
        ) {
            return true;
        }
    }

    return false;
}

function upep_table_columns($table) {
    global $wpdb;
    $cache_key = 'upep_columns_' . md5($table);
    $cached = wp_cache_get($cache_key, 'user-pdf-export-pro');
    if (is_array($cached)) {
        return $cached;
    }

    $rows = $wpdb->get_results("SHOW COLUMNS FROM `$table`", ARRAY_A);
    $columns = array();
    foreach ((array) $rows as $row) {
        if (!empty($row['Field'])) {
            $columns[] = $row['Field'];
        }
    }

    wp_cache_set($cache_key, $columns, 'user-pdf-export-pro', 120);
    return $columns;
}

function upep_table_identity_where(array $columns, WP_User $user) {
    global $wpdb;
    $column_map = array_flip($columns);
    $parts = array();

    foreach (array('user_id', 'wp_user_id', 'customer_id', 'member_id', 'uid', 'wordpress_user_id') as $column) {
        if (isset($column_map[$column])) {
            $parts[] = $wpdb->prepare("`$column` = %d", $user->ID);
        }
    }

    foreach (array('email', 'user_email') as $column) {
        if (isset($column_map[$column])) {
            $parts[] = $wpdb->prepare("`$column` = %s", $user->user_email);
        }
    }

    foreach (array('username', 'user_login', 'login') as $column) {
        if (isset($column_map[$column])) {
            $parts[] = $wpdb->prepare("`$column` = %s", $user->user_login);
        }
    }

    return empty($parts) ? '' : '(' . implode(' OR ', $parts) . ')';
}

function upep_row_value_for_field(array $row, $field) {
    $aliases = array(
        'phone' => array('phone', 'phone_number', 'mobile', 'mobile_number', 'mobile_no', 'telephone', 'tel', 'user_phone', 'billing_phone', 'shipping_phone', 'contact_phone', 'contact_number', 'whatsapp', 'whatsapp_number'),
        'country' => array('country', 'user_country', 'billing_country', 'country_name', 'country_code'),
        'gsp_account' => array('gsp_account', 'gsp_account_id', 'gsp_account_number', 'account', 'account_id', 'account_number'),
        'wallet_balance' => array('wallet_balance', 'balance', 'account_balance', 'main_balance', 'available_balance'),
        'savings_balance' => array('savings_balance', 'saving_balance', 'savings', 'saving', 'savings_wallet_balance'),
    );

    if (isset($aliases[$field])) {
        foreach ($aliases[$field] as $column) {
            if (array_key_exists($column, $row)) {
                $value = upep_clean_value($row[$column]);
                if ($value !== '') {
                    return $value;
                }
            }
        }
    }

    $keywords = upep_keywords_for_field($field);
    foreach ($row as $column => $value) {
        $column_lc = strtolower((string) $column);
        $matched = upep_keyword_groups_match($column_lc, $keywords);

        if ($matched) {
            $value = upep_clean_value($value);
            if ($value !== '') {
                return $value;
            }
        }
    }

    return '';
}

function upep_registrationmagic_phone(WP_User $user) {
    global $wpdb;

    $tables = $wpdb->get_col($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($wpdb->prefix . 'rm_') . '%'));
    if (empty($tables)) {
        return '';
    }

    $submissions_table = '';
    $submission_fields_table = '';
    $fields_table = '';

    foreach ($tables as $table) {
        $name = strtolower((string) $table);
        if (substr($name, -strlen('rm_submissions')) === 'rm_submissions') {
            $submissions_table = $table;
        } elseif (substr($name, -strlen('rm_submission_fields')) === 'rm_submission_fields') {
            $submission_fields_table = $table;
        } elseif (substr($name, -strlen('rm_fields')) === 'rm_fields') {
            $fields_table = $table;
        }
    }

    if ($submissions_table === '' || $submission_fields_table === '') {
        return '';
    }

    $submission_columns = upep_table_columns($submissions_table);
    $submission_id_column = upep_first_existing_column($submission_columns, array('submission_id', 'id'));
    if ($submission_id_column === '') {
        return '';
    }

    $where = array();
    $submission_column_map = array_flip($submission_columns);
    foreach (array('user_email', 'email') as $column) {
        if (isset($submission_column_map[$column])) {
            $where[] = $wpdb->prepare("`$column` = %s", $user->user_email);
        }
    }
    foreach (array('user_id', 'wp_user_id') as $column) {
        if (isset($submission_column_map[$column])) {
            $where[] = $wpdb->prepare("`$column` = %d", $user->ID);
        }
    }

    if (empty($where)) {
        return '';
    }

    $submission_id = $wpdb->get_var("SELECT `$submission_id_column` FROM `$submissions_table` WHERE " . implode(' OR ', $where) . " ORDER BY `$submission_id_column` DESC LIMIT 1");
    if (!$submission_id) {
        return '';
    }

    $field_columns = upep_table_columns($submission_fields_table);
    $value_column = upep_first_existing_column($field_columns, array('value', 'field_value'));
    $field_id_column = upep_first_existing_column($field_columns, array('field_id', 'form_field_id'));
    $field_submission_id_column = upep_first_existing_column($field_columns, array('submission_id', 'sub_id'));

    if ($value_column === '' || $field_submission_id_column === '') {
        return '';
    }

    if ($fields_table !== '' && $field_id_column !== '') {
        $fields_columns = upep_table_columns($fields_table);
        $label_column = upep_first_existing_column($fields_columns, array('label', 'field_label', 'field_name'));
        $type_column = upep_first_existing_column($fields_columns, array('field_type', 'type'));
        $id_column = upep_first_existing_column($fields_columns, array('field_id', 'id'));

        if ($id_column !== '' && ($label_column !== '' || $type_column !== '')) {
            $label_check = $label_column !== '' ? "LOWER(f.`$label_column`) LIKE '%phone%' OR LOWER(f.`$label_column`) LIKE '%mobile%' OR LOWER(f.`$label_column`) LIKE '%tel%'" : '0=1';
            $type_check = $type_column !== '' ? "LOWER(f.`$type_column`) LIKE '%phone%' OR LOWER(f.`$type_column`) LIKE '%mobile%' OR LOWER(f.`$type_column`) LIKE '%tel%'" : '0=1';
            $value = $wpdb->get_var($wpdb->prepare(
                "SELECT sf.`$value_column`
                 FROM `$submission_fields_table` sf
                 INNER JOIN `$fields_table` f ON f.`$id_column` = sf.`$field_id_column`
                 WHERE sf.`$field_submission_id_column` = %s AND ($label_check OR $type_check)
                 LIMIT 1",
                $submission_id
            ));
            $value = upep_clean_value($value);
            if ($value !== '') {
                return $value;
            }
        }
    }

    $values = $wpdb->get_col($wpdb->prepare(
        "SELECT `$value_column` FROM `$submission_fields_table` WHERE `$field_submission_id_column` = %s",
        $submission_id
    ));

    foreach ((array) $values as $value) {
        $phone = upep_extract_phone_from_text($value);
        if ($phone !== '') {
            return $phone;
        }
    }

    return '';
}

function upep_phone_pattern_from_user_meta($user_id) {
    $meta = get_user_meta($user_id);
    foreach ($meta as $key => $values) {
        $key_lc = strtolower((string) $key);
        if (
            strpos($key_lc, 'balance') !== false ||
            strpos($key_lc, 'amount') !== false ||
            strpos($key_lc, 'account') !== false ||
            strpos($key_lc, 'token') !== false ||
            strpos($key_lc, 'session') !== false ||
            strpos($key_lc, 'capabilities') !== false
        ) {
            continue;
        }

        foreach ((array) $values as $value) {
            $phone = upep_extract_phone_from_text($value);
            if ($phone !== '') {
                return $phone;
            }
        }
    }

    return '';
}

function upep_extract_phone_from_text($value) {
    $value = upep_clean_value($value);
    if ($value === '') {
        return '';
    }

    if (preg_match('/(?:\+|00)?[0-9][0-9\s().-]{6,}[0-9]/', $value, $match)) {
        $phone = trim($match[0]);
        $digits = preg_replace('/\D+/', '', $phone);

        if (strlen($digits) >= 7 && strlen($digits) <= 16) {
            return $phone;
        }
    }

    return '';
}

function upep_first_existing_column(array $columns, array $candidates) {
    $map = array_flip($columns);
    foreach ($candidates as $candidate) {
        if (isset($map[$candidate])) {
            return $candidate;
        }
    }

    return '';
}

function upep_clean_value($value) {
    if (is_array($value) || is_object($value)) {
        $value = wp_json_encode($value);
    }

    return trim(wp_strip_all_tags((string) $value));
}

function upep_extra_meta($user_id) {
    $excluded = array(
        'session_tokens',
        'wp_capabilities',
        'wp_user_level',
        'dismissed_wp_pointers',
        'admin_color',
        'rich_editing',
        'syntax_highlighting',
        'comment_shortcuts',
        'show_admin_bar_front',
        'use_ssl',
        'show_welcome_panel',
    );
    $meta = get_user_meta($user_id);
    $pairs = array();

    foreach ($meta as $key => $values) {
        if (in_array($key, $excluded, true) || strpos($key, 'capabilities') !== false || strpos($key, 'user_level') !== false) {
            continue;
        }

        $value = isset($values[0]) ? maybe_unserialize($values[0]) : '';
        if (is_array($value) || is_object($value)) {
            $value = wp_json_encode($value);
        }

        $value = trim(wp_strip_all_tags((string) $value));
        if ($value !== '') {
            $pairs[] = $key . ': ' . $value;
        }
    }

    return implode('; ', array_slice($pairs, 0, 20));
}

function upep_users_data($columns) {
    $users = get_users(array(
        'orderby' => 'ID',
        'order' => 'ASC',
        'number' => 999999,
        'fields' => 'all_with_meta',
    ));
    $rows = array();

    foreach ($users as $user) {
        $row = array();
        foreach ($columns as $column) {
            $row[$column] = upep_value($user, $column);
        }
        $rows[] = $row;
    }

    return $rows;
}

function upep_render_admin_page() {
    if (!current_user_can('list_users')) {
        wp_die('You are not allowed to export users.');
    }

    $columns = upep_columns();
    $selected = upep_selected_columns();
    $rows = upep_users_data($selected);
    ?>
    <div class="wrap">
        <h1>User PDF Export</h1>
        <p>Export all WordPress users and their details in a neatly arranged PDF table.</p>
        <style>
            .upep-panel{background:#fff;border:1px solid #dcdcde;border-radius:8px;margin:16px 0;padding:16px}
            .upep-columns{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:10px}
            .upep-columns label{display:flex;gap:8px;align-items:center;background:#f8fafc;border:1px solid #e2e8f0;border-radius:6px;padding:8px 10px}
            .upep-actions{display:flex;flex-wrap:wrap;gap:12px;margin:16px 0}.upep-scroll{overflow-x:auto}.upep-meta{color:#64748b;margin-bottom:10px}
            .upep-table th{white-space:nowrap}.upep-table td{vertical-align:top}
        </style>

        <form method="get" class="upep-panel">
            <input type="hidden" name="page" value="upep-user-pdf-export">
            <h2>Choose Preview Columns</h2>
            <div class="upep-columns">
                <?php foreach ($columns as $key => $label) : ?>
                    <label>
                        <input type="checkbox" name="upep_columns[]" value="<?php echo esc_attr($key); ?>" <?php checked(in_array($key, $selected, true)); ?>>
                        <?php echo esc_html($label); ?>
                    </label>
                <?php endforeach; ?>
            </div>
            <p><button class="button">Update Table</button></p>
        </form>

        <div class="upep-actions">
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="upep_export_selected_pdf">
                <?php wp_nonce_field('upep_export_selected_pdf'); ?>
                <?php foreach ($selected as $column) : ?>
                    <input type="hidden" name="upep_columns[]" value="<?php echo esc_attr($column); ?>">
                <?php endforeach; ?>
                <button class="button button-primary button-hero">Export Current Table PDF</button>
            </form>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="upep_export_all_pdf">
                <?php wp_nonce_field('upep_export_all_pdf'); ?>
                <button class="button button-secondary button-hero">Bulk Export All Users PDF</button>
            </form>
        </div>

        <div class="upep-panel">
            <div class="upep-meta"><strong><?php echo esc_html(number_format_i18n(count($rows))); ?></strong> users found</div>
            <div class="upep-scroll">
                <table class="widefat striped upep-table">
                    <thead>
                        <tr>
                            <?php foreach ($selected as $column) : ?>
                                <th><?php echo esc_html($columns[$column]); ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($rows)) : ?>
                            <tr><td colspan="<?php echo esc_attr(count($selected)); ?>">No users found.</td></tr>
                        <?php endif; ?>
                        <?php foreach ($rows as $row) : ?>
                            <tr>
                                <?php foreach ($selected as $column) : ?>
                                    <td><?php echo esc_html($row[$column]); ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php
}

function upep_export_selected_pdf() {
    if (!current_user_can('list_users')) {
        wp_die('You are not allowed to export users.');
    }

    check_admin_referer('upep_export_selected_pdf');
    upep_send_pdf(upep_selected_columns(), 'wordpress-selected-users');
}
add_action('admin_post_upep_export_selected_pdf', 'upep_export_selected_pdf');

function upep_export_all_pdf() {
    if (!current_user_can('list_users')) {
        wp_die('You are not allowed to export users.');
    }

    check_admin_referer('upep_export_all_pdf');
    upep_send_pdf(upep_bulk_export_columns(), 'wordpress-all-users');
}
add_action('admin_post_upep_export_all_pdf', 'upep_export_all_pdf');

function upep_send_pdf($selected_columns, $filename_prefix) {
    $column_labels = upep_columns();
    $headers = array();
    foreach ($selected_columns as $column) {
        $headers[] = $column_labels[$column];
    }

    $rows = array();
    foreach (upep_users_data($selected_columns) as $row) {
        $rows[] = array_values($row);
    }

    $pdf = new UPEP_Simple_PDF_Table(
        get_bloginfo('name') . ' - User Details',
        'Generated ' . current_time('Y-m-d H:i') . ' - ' . count($rows) . ' users',
        $headers,
        $rows
    );

    nocache_headers();
    header('Content-Type: application/pdf');
    header('Content-Disposition: attachment; filename="' . $filename_prefix . '-' . current_time('Y-m-d-His') . '.pdf"');
    header('Content-Transfer-Encoding: binary');
    echo $pdf->render();
    exit;
}

class UPEP_Simple_PDF_Table {
    private $title;
    private $subtitle;
    private $headers;
    private $rows;
    private $objects = array();
    private $pages = array();
    private $width;
    private $height;
    private $margin = 24;
    private $font_size = 8;
    private $line_height = 15;

    public function __construct($title, $subtitle, array $headers, array $rows) {
        $this->title = $title;
        $this->subtitle = $subtitle;
        $this->headers = $headers;
        $this->rows = $rows;
        $column_count = count($headers);

        if ($column_count > 8) {
            $this->width = 1191;
            $this->height = 842;
            $this->font_size = 8;
            $this->line_height = 18;
        } elseif ($column_count > 6) {
            $this->width = 842;
            $this->height = 595;
            $this->font_size = 8;
            $this->line_height = 17;
        } else {
            $this->width = 595;
            $this->height = 842;
            $this->font_size = 9;
            $this->line_height = 18;
        }
    }

    public function render() {
        $this->build_pages();
        $catalog_id = 1;
        $pages_id = 2;
        $font_id = 3;
        $this->objects[$catalog_id] = "<< /Type /Catalog /Pages $pages_id 0 R >>";
        $this->objects[$font_id] = '<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>';

        $kids = array();
        $next_id = 4;
        foreach ($this->pages as $content) {
            $content_id = $next_id++;
            $page_id = $next_id++;
            $this->objects[$content_id] = "<< /Length " . strlen($content) . " >>\nstream\n" . $content . "\nendstream";
            $this->objects[$page_id] = "<< /Type /Page /Parent $pages_id 0 R /MediaBox [0 0 {$this->width} {$this->height}] /Resources << /Font << /F1 $font_id 0 R >> >> /Contents $content_id 0 R >>";
            $kids[] = "$page_id 0 R";
        }

        $this->objects[$pages_id] = '<< /Type /Pages /Kids [' . implode(' ', $kids) . '] /Count ' . count($kids) . ' >>';
        ksort($this->objects);

        $pdf = "%PDF-1.4\n";
        $offsets = array(0);
        foreach ($this->objects as $id => $object) {
            $offsets[$id] = strlen($pdf);
            $pdf .= "$id 0 obj\n$object\nendobj\n";
        }

        $xref = strlen($pdf);
        $pdf .= "xref\n0 " . (count($this->objects) + 1) . "\n";
        $pdf .= "0000000000 65535 f \n";
        for ($i = 1; $i <= count($this->objects); $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }
        $pdf .= "trailer\n<< /Size " . (count($this->objects) + 1) . " /Root $catalog_id 0 R >>\n";
        $pdf .= "startxref\n$xref\n%%EOF";

        return $pdf;
    }

    private function build_pages() {
        $page_number = 1;
        $content = $this->new_page($page_number);
        $y = $this->height - 88;
        $column_count = max(1, count($this->headers));
        $column_width = ($this->width - ($this->margin * 2)) / $column_count;
        $this->draw_header($content, $y, $column_width);
        $y -= $this->line_height;

        foreach ($this->rows as $row) {
            if ($y < $this->margin + 28) {
                $this->pages[] = $content;
                $page_number++;
                $content = $this->new_page($page_number);
                $y = $this->height - 88;
                $this->draw_header($content, $y, $column_width);
                $y -= $this->line_height;
            }

            $this->draw_row($content, $row, $y, $column_width, false);
            $y -= $this->line_height;
        }

        if (empty($this->rows)) {
            $content .= $this->text($this->margin, $y - 20, 'No users found.', 10);
        }

        $this->pages[] = $content;
    }

    private function new_page($page_number) {
        return $this->text($this->margin, $this->height - 34, $this->title, 14)
            . $this->text($this->margin, $this->height - 52, $this->subtitle, 9)
            . $this->text($this->width - 88, 18, 'Page ' . $page_number, 8);
    }

    private function draw_header(&$content, $y, $column_width) {
        $content .= "0.93 0.95 0.98 rg\n";
        $content .= $this->rect($this->margin, $y - 4, $this->width - ($this->margin * 2), $this->line_height, true);
        $this->draw_row($content, $this->headers, $y, $column_width, true);
    }

    private function draw_row(&$content, array $row, $y, $column_width, $header) {
        $x = $this->margin;
        $font_size = $header ? $this->font_size + 1 : $this->font_size;
        $text_y = $y + (($this->line_height - $font_size) / 2);
        foreach ($this->headers as $index => $unused) {
            $value = isset($row[$index]) ? (string) $row[$index] : '';
            $content .= "0.78 0.82 0.88 RG\n";
            $content .= $this->rect($x, $y - 4, $column_width, $this->line_height, false);
            $content .= $this->text($x + 4, $text_y, $this->fit($value, $column_width - 8), $font_size);
            $x += $column_width;
        }
    }

    private function rect($x, $y, $w, $h, $fill) {
        return sprintf("%.2F %.2F %.2F %.2F re %s\n", $x, $y, $w, $h, $fill ? 'f' : 'S');
    }

    private function text($x, $y, $text, $size) {
        return sprintf("0 0 0 rg\nBT /F1 %d Tf %.2F %.2F Td (%s) Tj ET\n", $size, $x, $y, $this->escape($text));
    }

    private function fit($text, $width) {
        $text = preg_replace('/\s+/', ' ', wp_strip_all_tags((string) $text));
        $max_chars = max(4, (int) floor($width / max(4, $this->font_size * 0.62)));

        if (strlen($text) <= $max_chars) {
            return $text;
        }

        return substr($text, 0, $max_chars - 3) . '...';
    }

    private function escape($text) {
        $text = str_replace(array("\r", "\n", "\t"), ' ', (string) $text);
        $text = preg_replace('/[^\x20-\x7E]/', '', $text);
        return str_replace(array('\\', '(', ')'), array('\\\\', '\\(', '\\)'), $text);
    }
}
